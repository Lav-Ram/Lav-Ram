package com.cg.capbookproject.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.capbookproject.beans.User;


@Repository
public interface ICapbookDAO extends JpaRepository<User,Integer>{

	@Query(value="select * from user_table where email=?1 and password=?2", nativeQuery=true)
	public User checkUser(String email,String password);
	@Query(value="select * from user_table where email=?1", nativeQuery=true)
	public User verifyMail(String email);
	

	
	
}
