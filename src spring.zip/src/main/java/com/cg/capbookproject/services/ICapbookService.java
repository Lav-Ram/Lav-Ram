package com.cg.capbookproject.services;

import java.util.List;
import java.util.Optional;

import com.cg.capbookproject.beans.User;

import com.cg.capbookproject.exceptions.CapbookException;

public interface ICapbookService {
	public User addDetails(User user);

	public List<User> getDetails();

	public boolean updatePassword( User user,String newpassword,String confirmPassword);

	public void deleteDetails(int userId) throws CapbookException;

	public User findSingleUser(int userId);

	public boolean checkUser(String email,String password);
	public boolean verifyEmail(String email);
	public void forgotPassword(String email,User user, String newPass, String confirmPass) ;


}
