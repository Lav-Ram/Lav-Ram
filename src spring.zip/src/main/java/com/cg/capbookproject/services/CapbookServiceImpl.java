package com.cg.capbookproject.services;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capbookproject.beans.User;
import com.cg.capbookproject.dao.ICapbookDAO;
import com.cg.capbookproject.exceptions.CapbookException;

@Service
public class CapbookServiceImpl implements ICapbookService {
	@Autowired
	ICapbookDAO userDao;

	public List<User> getDetails() {

		return userDao.findAll();
	}

	public User addDetails(User user) {
		return userDao.save(user);
	}

	public boolean updatePassword(User user,String password,String confirmPassword) {

		/*
		 * User u = userDao.findById(userId).get();
		 * 
		 * u.setFname(user.getFname()); u.setLname(user.getLname());
		 * u.setPassword(user.getPassword());
		 * u.setConfirmpassword(user.getConfirmpassword()); u.setEmail(user.getEmail());
		 * 
		 * u.setBirthdate(user.getBirthdate());
		 * 
		 * return userDao.save(u);
		 */
		 int id=user.getUserId();
		 Optional<User> optional = userDao.findById(id);
		if (optional.isPresent()) {
			User u = optional.get();

			u.setFirstName(user.getFirstName());
			u.setLastName(user.getLastName());
			u.setPassword(password);
			u.setConfirmPassword(confirmPassword);
			u.setEmail(user.getEmail());
            u.setBirthDate(user.getBirthDate());

			 userDao.save(u);
			 return true;

		} else {
			
			return false;
		}
	}

	@Override
	public void deleteDetails(int userId)  throws CapbookException{
		try {
		userDao.deleteById(userId);
		}
		catch( Exception ex) {
			throw new CapbookException(ex.getMessage());
		}
	}

	@Override // finding by single stock
	public User findSingleUser(int userId) {
     return userDao.findById(userId).get();
	}

	@Override
	public boolean checkUser(String email,String password)  {
		
		User exists= userDao.checkUser(email,password);
		if(exists!=null) {
			return true;
			
		}
		else {
			return false;
			}
		 }
	

	@Override
	public boolean verifyEmail(String email)   {
		
		User exists= userDao.verifyMail(email);
		if(exists!=null) {
			return true;
			
		}
		else {
			return false;
		}
		
	}
	
	public void forgotPassword(String email,User user,String newPass, String confirmPass)  
   	{
		
   	
   		     List<User> detail = getDetails();
   		for(User users : detail) 
   		{
   			if(users.getEmail().equalsIgnoreCase(email))
   			{
   				
   					//String encodedString = Base64.getEncoder().encodeToString(newPass.getBytes());
   					users.setPassword(newPass);
   					users.setConfirmPassword(confirmPass);
   					userDao.save(users);
   				
   			}
   			
   		}
   		
		
		
		}
	}



