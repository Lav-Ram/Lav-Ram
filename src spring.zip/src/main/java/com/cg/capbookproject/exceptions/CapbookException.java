package com.cg.capbookproject.exceptions;

public class CapbookException extends Exception{
    public CapbookException(String s) {
        super(s);
    }
    public CapbookException() {
        super();
    }
}
