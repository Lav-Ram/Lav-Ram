package com.cg.capbookproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapbookProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapbookProjectApplication.class, args);
	}

	
}
