export class User {
    public userId: number;
    public firstName: string;
    public lastName: string;
    public email: string;
    public password: string;
    public confirmPassword: string;
    public birthDate: string;
    public phoneNo: string;
}
