import { Injectable } from '@angular/core';
//import { HttpClient } from 'selenium-webdriver/http';
import { User } from './user';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CapbookService {
  constructor(private httpClient:HttpClient
    ){}
  static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
  let config = {
    'required': 'Required',
    'invalidEmailAddress': 'Invalid email address',
    //'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
    'minlength': `Minimum length ${validatorValue.requiredLength}`
  };
  return config[validatorName];
}
  
  static emailValidator(control) {
    // RFC 2822 compliant regex
    if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
      return null;
    } else {
      return { 'invalidEmailAddress': true };
    }

   /* static passwordValidator(control) {
     
      if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/))
       {
        return null;
      } 
      else {

        return { 'invalidPassword': true };
      }*/
  }
  public createUser(userDetails){
    return this.httpClient.post<User>("http://localhost:9099/add", userDetails);
  }
  public checkUsers(email,password):Observable<boolean>
  {
    let url='http://localhost:9099/checkusers/'+email+'/'+password;
    console.log(url);
    return this.httpClient.get<boolean>(url);
  }
  public verifyEmail(email):Observable<boolean>
  {
    let url='http://localhost:9099/verifyemail/'+email;
    console.log(url);
    return this.httpClient.get<boolean>(url);
  }
  
   public changepassword(email,password,confirmPassword):Observable<boolean>
  {
  let url='http://localhost:9099/update/'+email+'/'+password+'/'+confirmPassword;
    console.log(url);
    return this.httpClient.put<boolean>(url,"userDetails");
   // return this.httpClient.put<boolean>('http://localhost:9099/update'+email+'/'+password+'/'+confirmpassword,"userDetails");
  }
  public forgotPassword(user,newpass,confirmPassword){

    return this.httpClient.put('http://localhost:9099/'+user.email+'/'+newpass+'/'+confirmPassword,user);
  }
}
 
