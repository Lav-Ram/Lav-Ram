import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import {FormsModule} from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { ForgetpasswordComponent } from './ForgetPassword/forgetpassword.component';
import { ChangepasswordComponent } from './ChangePassword/changepassword.component';

import { ProfileimageComponent } from './Profile/profileimage.component';
import { ProfilepageComponent } from './profilepage/profilepage.component';
import { CapbookService } from './capbook.service';
import { HttpClientModule } from '@angular/common/http';
import { ViewComponent } from './view/view.component';
import { VerifyComponent } from './verify/verify.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,

    SignupComponent,
    ForgetpasswordComponent,
    ChangepasswordComponent,
    ProfileimageComponent,
    ProfilepageComponent,
    ViewComponent,
    VerifyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [CapbookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
