import { Component, OnInit, Output } from '@angular/core';
import { CapbookService } from '../capbook.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  
// userDetails: User;

 constructor(private capbookService:CapbookService,private router:Router) { 
    //this.userDetails=new User();
  }
  ngOnInit() {
  }
  user={
    email:''
  }
  password;
  confirmPassword;
  

 
forgot(){
  //this.capbookService.checkByMail_Answer(this.user.email,this.password,this.confirmpassword).subscribe(()=>{
     if(this.password==this.confirmPassword) {
       
    
  this.capbookService.forgotPassword(this.user,this.password,this.confirmPassword).subscribe(()=>{
        window.alert("Password Changed...");
        this.router.navigate(['/login'])
      });
    }
    else{
      window.alert("Password and confirmPassword doesn't match");
    }
  
  
}
}


